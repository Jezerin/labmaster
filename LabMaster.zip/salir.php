<link href='labmaster.css' rel='stylesheet' type='text/css'>
<?php

session_start(); 
session_destroy(); 
	
	echo "	<html>
	
			<head> 
				
					<title>Salir</title> 
			</head> 
			
					Ha salido del sistema <br> <br>
					
					<a href=login.html>Login</a> 

			</body> 
			
			</html> ";

?>