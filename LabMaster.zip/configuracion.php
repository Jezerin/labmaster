<?php include("sesion.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Documento sin t&iacute;tulo</title>
</head>

	<frameset cols="220,*" frameborder="yes" border="1" framespacing="0">
  		<frame src="configurar.php" name="cleftFrame" scrolling="No" noresize="noresize" id="cleftFrame" title="menu_conf" />
  		<frame src="contenido_conf.php" name="cmainFrame" id="cmainFrame" title="contenido_conf" />
	</frameset>

	<noframes>

<body>



</body>

	</noframes>
    
</html>
