<?php include("sesion.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Navegacion</title>
    <link href='labmaster.css' rel='stylesheet' type='text/css'>
<body>

	<br/>
    <br/>
	
    <div align="center"> 
    
        <ul id="navi"> 	
            <li><a href='index.php' target="_top">Home</a></li>
            <li><a href='reservar.php' target='mainFrame'>Reservar</a></li>
            <li><a href='ver_reservaciones.php' target='mainFrame'>Reservaciones</a></li>
            <li><a href='configuracion.php' target='mainFrame'>Configuraciones</a></li>
            <li><a href='salir.php' target='_top'>Salir</a></li>
        </ul>
        
     </div>

</body>

</html>
