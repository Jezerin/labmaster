<?php include("sesion.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Documento sin t&iacute;tulo</title>
	<link href='labmaster.css' rel='stylesheet' type='text/css'>
</head>

<body>

	<div id="menu">
		
			<ul>
				<li><a href="realiza_reservacion.php" target="rmainFrame">Realizar Reservacion</a></li>
				<li><a href="ver_disponibilidad.php" target="rmainFrame">Ver Disponibilidad</a></li>
				<li><a href="cancela_reservacion.php" target="rmainFrame">Cancelar Reservacion</a></li>
			</ul>
			
		</div>

</body>

</html>
